/**
 * Created by she on 2018/11/19.
 */
export const UP_BOOK_DATA = 'UP_DATA'
export const ADD_BROAD_SHOW = "ADD_BROAD_SHOW"
export const UP_SHELF_DATA = "UP_SHELF_DATA"
export const UP_ADMISSION = "UP_ADMISSION"
export const UP_MORE_DATA = 'UP_MORE_DATA'
export const MORE_SHOW = 'MORE_SHOW'
export const DETAILS_SHOW = 'DETAILS_SHOW'
export const DETAILS_DATA = 'DETAILS_DATA'
export const RANKINGMAN_DATA = 'RANKINGMAN_DATA'
export const RANKINGGIRL_DATA = 'RANKINGGIRL_DATA'
export const RANKINGCLASSIC_DATA = 'RANKINGCLASSIC_DATA'
export const MAN_TOP = 'MAN_TOP'
export const GIRL_TOP = 'GIRL_TOP'
export const CLASSIC_TOP = 'CLASSIC_TOP'
export const RANK_SHOW = 'RANK_SHOW'
export const RANK_BOOK_DATA = 'RANK_BOOK_DATA'
export const INPSHOW = 'INPSHOW'
export const READSHOW = 'READSHOW'
export const PUST_BOOKREDS = 'PUST_BOOKREDS'
export const DELETE_BOOK = 'DELETE_BOOK'
