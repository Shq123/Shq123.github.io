<template>
  <div class="navImg">
    <img src="../../../static/img/navLogo.png">
  </div>
</template>
<script>
    export default {
        name:'navImg'
    }
</script>

<style scoped>
  .navImg{
    width: 100%;
    height: 30%;
  }
  .navImg img{
    width: 100%;
    height: 100%;
  }
</style>
